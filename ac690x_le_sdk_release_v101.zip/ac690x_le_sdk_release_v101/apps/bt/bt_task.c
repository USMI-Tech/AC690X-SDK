/*********************************************************************************************
    *   Filename        : bt_task.c

    *   Description     :

    *   Author          : Bingquan

    *   Email           : bingquan_cai@zh-jieli.com

    *   Last modifiled  : 2017-01-12 09:23

    *   Copyright:(c)JIELI  2011-2016  @ , All Rights Reserved.
*********************************************************************************************/
#include "power_api.h"
#include "thread.h"
#include "init.h"
#include "task_schedule.h"
#include "utils.h"
#include "sdk_cfg.h"
#include "uart_interface.h"
#include "ble/le_controller.h"

/**
 * @brief btstack_main : Must definition
 *
 * @return
 */
int btstack_main(void);

/**
 * @brief btstack_input_init : Definition depend on whether user input
 */
_WEAK_
void btstack_input_init(void);

struct bt_task_hdl {
    void *timer[2];
};
static struct bt_task_hdl hdl;

static char g_stdin;

#define __this      (&hdl)

/**
 * @brief Bluetooth Low Power setting
 */
const struct bt_low_power_param bt_power_param = {
    .config     = APP_BT_LOWPOWER_SELECT,
    .osc_type   = APP_BT_LOWPOWER_OSC_TYPE,
    .osc_hz     = APP_BT_LOWPOWER_OSC_HZ,
    .is_use_PR  = 0,
    .delay_us   = 160000000 / 1000000L,
    .d2sh_dis_sw = 0,
};

/**
 * @brief Bluetooth LE MAC Address
 */
const bd_addr_t le_mac_addr[BD_ADDR_LEN] = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66};

/**
 * @brief Bluetooth LE Features setting
 */
int btstack_le_features = LE_FEATURES;


void (*thread_fun[PRIORITY_NUM])(u8) = {0};

volatile u8 g_task_sleep_bitmap = 0;
volatile u8 g_thread_created = 0;

#define THREAD_SUSPEND(x)   g_task_sleep_bitmap |= BIT(x)
#define THREAD_RESUME(x)    g_task_sleep_bitmap &= ~BIT(x)

#define TASK_IS_AWAKE()   ((g_task_sleep_bitmap & g_thread_created ) != g_thread_created )
#define TASK_IS_SLEEP()   ((g_task_sleep_bitmap & g_thread_created ) == g_thread_created )

static OS_SEM sem;

static void __bt_task_wakeup(void)
{
    /* puts("<\n"); */
    os_sem_set(&sem, 1);
    os_sem_post(&sem);
}

static void __bt_task_sleep(void)
{
    /* puts(">\n"); */
    os_sem_pend(&sem, 0);
}


int os_create_thread(void (*fun)(u8), u8 priority)
{
    thread_fun[priority] = fun;

    g_thread_created |= BIT(priority);
    /*printf("prio: %d, fun=%x\n", priority, fun);*/

    return 0;
}

int os_delete_thread(u8 priority)
{
    thread_fun[priority] = NULL;

    g_thread_created &= ~BIT(priority);

    return 0;
}

int os_suspend_thread(u8 priority, u8 timeout)
{
    THREAD_SUSPEND(priority);

    if (TASK_IS_SLEEP()) {
        bt_power_off_unlock();
        __bt_task_sleep();
    }

    return 0;
}

int  os_resume_thread(u8 priority)
{
    bt_power_off_lock();

    THREAD_RESUME(priority);

    __bt_task_wakeup();

    return 0;
}

const struct thread_interface os_thread_ins = {
    .os_create = os_create_thread,
    .os_delete = os_delete_thread,
    .os_suspend = os_suspend_thread,
    .os_resume = os_resume_thread,
};

void task_run_loop(void)
{
    int i;

    bt_power_off_lock();
    for (i = 0; i < PRIORITY_NUM; i++) {
        if (thread_fun[i]) {
            thread_fun[i](i);
        }
    }
}



/**
 * @brief bt_task 协议栈任务
 *
 * @param args
 */
static void bt_task(void *args)
{
    if (!bt_power_is_poweroff_post()) {
        puts("\n**********");
        puts(TASK_NAME_BTSTACK);
        puts("**********\n");
    }

    if (bt_power_is_poweroff_post()) {
        /* puts("bt deep sleep wakeup\n"); */
        RF_poweroff_recover();//
    }

    thread_init(&os_thread_ins);

    bt_power_init(&bt_power_param);

    le_controller_init();

    if (bt_power_is_poweroff_post()) {
        bt_poweroff_recover();
    }

    bt_osc_internal_cfg(0x11, 0x11);

    /* le_controller_set_mac((bd_addr_t *)&le_mac_addr); */

    if (!bt_power_is_poweroff_post()) {
        btstack_main();
    }

    if (btstack_input_init) {
        btstack_input_init();
    }

    while (1) {
        TASK_DEBUG_BTSTACK;

        /* if (g_stdin) */
        /* stdin_process(g_stdin); */

        task_run_loop();
    }
}



static void bt_task_stdin_process(void)
{
    OS_ENTER_CRITICAL();
    g_stdin = getbyte();
    OS_EXIT_CRITICAL();

    if (g_stdin) {
        __bt_task_wakeup();
    }
}


static void bt_task_init(void)
{
    if (!bt_power_is_poweroff_post()) {
        puts("app_initcall - bt_task_init\n");
    }

    os_sem_create(&sem, 1);

    os_task_create(bt_task, (void *)0, TASK_PRIO_BTSTACK, 10, TASK_NAME_BTSTACK);

    /* __this->timer[0] = periodic_timer_add(100, bt_task_stdin_process); */
}
app_initcall(bt_task_init);

