/*********************************************************************************************
    *   Filename        : le_counter.c

    *   Description     :

    *   Author          : Bingquan

    *   Email           : bingquan_cai@zh-jieli.com

    *   Last modifiled  : 2017-01-17 11:14

    *   Copyright:(c)JIELI  2011-2016  @ , All Rights Reserved.
*********************************************************************************************/

// *****************************************************************************
/* EXAMPLE_START(le_counter): LE Peripheral - Heartbeat Counter over GATT
 *
 * @text All newer operating systems provide GATT Client functionality.
 * The LE Counter examples demonstrates how to specify a minimal GATT Database
 * with a custom GATT Service and a custom Characteristic that sends periodic
 * notifications.
 */
// *****************************************************************************

#include <btstack_run_loop.h>
/* #include <stdint.h> */
/* #include <stdio.h> */
#include <stdlib.h>
#include <string.h>

#include "uart_interface.h"
#include "btstack_event.h"
#include "btstack.h"
#include "ble/att.h"
#include "btstack_memory.h"
#include "hci.h"
#include "hci_transport.h"
#include "l2cap.h"
#include "ble/sm.h"
#include "ble/att_server.h"
#include "ble/le_device_db.h"
#include "ble/att.h"
#include "imd_alert.h"

#define HEARTBEAT_PERIOD_MS 1000

/* @section Main Application Setup
 *
 * @text Listing MainConfiguration shows main application code.
 * It initializes L2CAP, the Security Manager and configures the ATT Server with the pre-compiled
 * ATT Database generated from $le_counter.gatt$. Finally, it configures the advertisements
 * and the heartbeat handler and boots the Bluetooth stack.
 * In this example, the Advertisement contains the Flags attribute and the device name.
 * The flag 0x06 indicates: LE General Discoverable Mode and BR/EDR not supported.
 */

/* LISTING_START(MainConfiguration): Init L2CAP SM ATT Server and start heartbeat timer */
static int  le_notification_enabled SEC(.non_volatile_ram);
static timer_source_t heartbeat SEC(.non_volatile_ram);
static btstack_packet_callback_registration_t hci_event_callback_registration SEC(.non_volatile_ram);
static hci_con_handle_t con_handle SEC(.non_volatile_ram);

static const char gap_device_name[] = "JL Alert";
static const uint8_t test_read_value[] = {0x01, 0x02};

static u8 ble_connect_flag SEC(.non_volatile_ram) = 0;
static u8 alert_level SEC(.non_volatile_ram) = 2;
static u8 Battery_level SEC(.non_volatile_ram);

static void packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size);
static uint16_t att_read_callback(hci_con_handle_t con_handle, uint16_t att_handle, uint16_t offset, uint8_t *buffer, uint16_t buffer_size);
static int att_write_callback(hci_con_handle_t con_handle, uint16_t att_handle, uint16_t transaction_mode, uint16_t offset, uint8_t *buffer, uint16_t buffer_size);
static void beat(void);
static void heartbeat_handler(struct sys_timer *ts);

static uint8_t get_battery_percent(void);
const uint8_t adv_data[] = {
    // Flags general discoverable, BR/EDR not supported
    0x02, 0x01, 0x06,
    // Name
    0x09, 0x09, 'J', 'L', ' ', 'A', 'l', 'e', 'r', 't',
};
const uint8_t adv_data_len = sizeof(adv_data);

static void le_counter_setup(void)
{

    // register for HCI events
    hci_event_callback_registration.callback = &packet_handler;
    hci_add_event_handler(&hci_event_callback_registration);

    le_l2cap_init();

    // setup le device db
    le_device_db_init();

    // setup SM: Display only
    sm_init();

    // setup ATT server
    att_server_init(profile_data, att_read_callback, att_write_callback);
    att_server_register_packet_handler(packet_handler);

    // setup advertisements
    uint16_t adv_int_min = 0x0030;
    uint16_t adv_int_max = 0x0030;
    uint8_t adv_type = 0;
    bd_addr_t null_addr;
    memset(null_addr, 0, 6);
    gap_advertisements_set_params(adv_int_min, adv_int_max, adv_type, 0, null_addr, 0x07, 0x00);
    gap_advertisements_set_data(adv_data_len, (uint8_t *) adv_data);
    gap_advertisements_enable(1);

    // set one-shot timer
    /* heartbeat.process = &heartbeat_handler; */
    /* btstack_run_loop_set_timer(&heartbeat, HEARTBEAT_PERIOD_MS); */
    /* btstack_run_loop_add_timer(&heartbeat); */
    sys_timer_register(&heartbeat, HEARTBEAT_PERIOD_MS, heartbeat_handler);

    // beat once
    beat();
}
/* LISTING_END */

/*
 * @section Heartbeat Handler
 *
 * @text The heartbeat handler updates the value of the single Characteristic provided in this example,
 * and request a ATT_EVENT_CAN_SEND_NOW to send a notification if enabled see Listing heartbeat.
 */

/* LISTING_START(heartbeat): Hearbeat Handler */
static int  counter SEC(.non_volatile_ram) = 0;
static char counter_string[20] SEC(.non_volatile_ram);
static int  counter_string_len SEC(.non_volatile_ram);


static void beat(void)
{
    counter++;
    counter_string_len = sprintf(counter_string, "counter %04u", counter);
    puts(counter_string);
}

uint8_t alert_timer_cycle SEC(.non_volatile_ram) = 0;
uint8_t alert_timer_cnt SEC(.non_volatile_ram) = 0;

#define RING_IO_BIT   4
#define  ALERT_RING_ON()         {JL_PORTA->DIR &= ~BIT(RING_IO_BIT), JL_PORTA->OUT |=  BIT(RING_IO_BIT);}
#define  ALERT_RING_OFF()        {JL_PORTA->DIR &= ~BIT(RING_IO_BIT), JL_PORTA->OUT &= ~BIT(RING_IO_BIT);}
#
void alert_deal(void)
{
    if (alert_level == 1) {
        alert_timer_cycle = 2;
    } else if (alert_level == 2) {
        alert_timer_cycle = 0xFF;
    } else {
        alert_timer_cycle = 0;
    }
    alert_timer_cnt = 0;
    ALERT_RING_OFF();
}

static uint32_t running_timer_cnt SEC(.non_volatile_ram) = 0;

static void alert_handler(void)
{

    running_timer_cnt++;

    if ((running_timer_cnt % 30) == 0) {
        if (Battery_level > 1) {
            Battery_level--;
        }
    }

    if (con_handle == 0) {
        ALERT_RING_OFF();
        return;
    }

    /* printf("------bat= %d--------\n", get_battery_percent()); */
    if (alert_timer_cycle) {
        if (alert_timer_cycle == 0xff) {
            ALERT_RING_ON();
            return;
        }

        alert_timer_cnt++;
        if (alert_timer_cnt == alert_timer_cycle) {
            ALERT_RING_ON();
        }

        if (alert_timer_cnt >= alert_timer_cycle * 2) {
            ALERT_RING_OFF();
            alert_timer_cnt = 0;
        }

    }

}

#define BAT_LEVER_RANG   (42 - 31)

extern u16 get_cur_battery_value(void);
static uint8_t get_battery_percent(void)
{
    u16 tmp16 =  get_cur_battery_value();

    printf("bat = %d\n", tmp16);

    Battery_level = ((tmp16 - 31) * 100) / BAT_LEVER_RANG;

    printf("percent = %d\n", Battery_level);

    if (Battery_level > 100) {
        Battery_level = 100;
    }

    return Battery_level;
}
static void heartbeat_handler(struct sys_timer *ts)
{
    static u32 count = 0;

    alert_handler();

    if (le_notification_enabled) {
        beat();
        att_server_request_can_send_now_event(con_handle);
    }
    /* btstack_run_loop_set_timer(ts, HEARTBEAT_PERIOD_MS); */
    /* btstack_run_loop_add_timer(ts); */

    sys_timer_register(&heartbeat, HEARTBEAT_PERIOD_MS, heartbeat_handler);
}
/* LISTING_END */

/*
 * @section Packet Handler
 *
 * @text The packet handler is used to:
 *        - stop the counter after a disconnect
 *        - send a notification when the requested ATT_EVENT_CAN_SEND_NOW is received
 */

/* LISTING_START(packetHandler): Packet Handler */
static void packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size)
{
    switch (packet_type) {
    case HCI_EVENT_PACKET:
        switch (hci_event_packet_get_type(packet)) {

        case HCI_EVENT_LE_META:
            switch (hci_event_le_meta_get_subevent_code(packet)) {
            case HCI_SUBEVENT_LE_CONNECTION_COMPLETE: {
                con_handle = little_endian_read_16(packet, 4);
                alert_deal();
                printf("HCI_SUBEVENT_LE_CONNECTION_COMPLETE : %0x\n", con_handle);
            }
            break;
            }
            break;

        case HCI_EVENT_DISCONNECTION_COMPLETE:
            puts("---ble disconnect!");
            le_notification_enabled = 0;
            con_handle = 0;
            break;

        case ATT_EVENT_CAN_SEND_NOW:
            if (le_notification_enabled) {
                puts("\n------notify send:");
                printf_buf((u8 *)counter_string, counter_string_len);
                /* att_server_notify(con_handle, ATT_CHARACTERISTIC_FF03_01_VALUE_HANDLE, (uint8_t *) counter_string, counter_string_len); */
            }
            break;
        }
        break;
    }
}
/* LISTING_END */

/*
 * @section ATT Read
 *
 * @text The ATT Server handles all reads to constant data. For dynamic data like the custom characteristic, the registered
 * att_read_callback is called. To handle long characteristics and long reads, the att_read_callback is first called
 * with buffer == NULL, to request the total value length. Then it will be called again requesting a chunk of the value.
 * See Listing attRead.
 */

/* LISTING_START(attRead): ATT Read */

// ATT Client Read Callback for Dynamic Data
// - if buffer == NULL, don't copy data, just return size of value
// - if buffer != NULL, copy data and return number bytes copied
// @param offset defines start of attribute value
static uint16_t att_read_callback(hci_con_handle_t connection_handle, uint16_t att_handle, uint16_t offset, uint8_t *buffer, uint16_t buffer_size)
{

    uint16_t  att_value_len = 0;
    uint16_t handle = att_handle;

    /* printf("READ Callback, handle %04x, offset %u, buffer size %u\n", handle, offset, buffer_size); */

    printf("read_callback, handle= 0x%04x\n", handle);

    switch (handle) {
    case ATT_CHARACTERISTIC_GAP_DEVICE_NAME_01_VALUE_HANDLE:
        att_value_len = strlen(gap_device_name);

        if ((offset >= att_value_len) || (offset + buffer_size) > att_value_len) {
            break;
        }

        if (buffer) {
            if (att_value_len > buffer_size) {
                att_value_len = buffer_size;
            }
            memcpy(buffer, gap_device_name, att_value_len);
            puts("\n------read gap_name:");
            printf_buf(buffer, att_value_len);
        }
        break;

    case ATT_CHARACTERISTIC_2A19_01_VALUE_HANDLE:
        att_value_len = 1;
        buffer[0] = get_battery_percent();
        break;

    default:
        break;
    }

    return att_value_len;

}


/* LISTING_END */


/*
 * @section ATT Write
 *
 * @text The only valid ATT write in this example is to the Client Characteristic Configuration, which configures notification
 * and indication. If the ATT handle matches the client configuration handle, the new configuration value is stored and used
 * in the heartbeat handler to decide if a new value should be sent. See Listing attWrite.
 */

/* LISTING_START(attWrite): ATT Write */
static int att_write_callback(hci_con_handle_t connection_handle, uint16_t att_handle, uint16_t transaction_mode, uint16_t offset, uint8_t *buffer, uint16_t buffer_size)
{
    int result = 0;

    u16 handle = att_handle;


    /* printf("WRITE Callback, handle %04x, mode %u, offset %u, data: ", handle, transaction_mode, offset); */

    printf("write_callback, handle= 0x%04x\n", handle);
    printf_buf(buffer, buffer_size);

    switch (handle) {

    /*
        case ATT_CHARACTERISTIC_FF03_01_CLIENT_CONFIGURATION_HANDLE:
            printf("\n------write ccc 0x%x\n", buffer[0]);
            le_notification_enabled = buffer[0];
            break;
    */

    case ATT_CHARACTERISTIC_2A06_01_VALUE_HANDLE:
        if (buffer[0] < 3) {
            alert_level = buffer[0];
            alert_deal();
        }
        break;

    default:
        break;
    }
    return 0;
}


/* LISTING_END */

int btstack_main(void)
{
    le_hci_init(ble_hci_transport_h4_instance(), 0, 0, 0);

    le_btstack_memory_init();
    le_counter_setup();

    // turn on!
    le_hci_power_control(HCI_POWER_ON);

    return 0;
}

#include "key.h"
#include "input_task.h"

static void btstack_input_process(u32 input)
{
    puts("\nbtstack_input_process - ");
    switch (input) {
    case INPUT_AD_KEY9_SHORT:
        puts("INPUT_AD_KEY9_SHORT\n");
        break;
    case INPUT_IO_KEY0_SHORT:
        puts("INPUT_IO_KEY0_SHORT\n");
        hci_send_cmd(&hci_disconnect, con_handle, 0x13);
        break;
    }
}

void btstack_input_init(void)
{
    puts("\nbtstack_input_init\n");
    input_register_hanler(btstack_input_process);
}



/* EXAMPLE_END */
