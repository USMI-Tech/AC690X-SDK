/*********************************************************************************************
    *   Filename        : le_counter.c

    *   Description     :

    *   Author          : Bingquan

    *   Email           : bingquan_cai@zh-jieli.com

    *   Last modifiled  : 2017-01-17 11:14

    *   Copyright:(c)JIELI  2011-2016  @ , All Rights Reserved.
*********************************************************************************************/

// *****************************************************************************
/* EXAMPLE_START(le_counter): LE Peripheral - Heartbeat Counter over GATT
 *
 * @text All newer operating systems provide GATT Client functionality.
 * The LE Counter examples demonstrates how to specify a minimal GATT Database
 * with a custom GATT Service and a custom Characteristic that sends periodic
 * notifications.
 */
// *****************************************************************************

#include <btstack_run_loop.h>
/* #include <stdint.h> */
/* #include <stdio.h> */
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "uart_interface.h"
#include "btstack_event.h"
#include "btstack.h"
#include "ble/att.h"
#include "btstack_memory.h"
#include "hci.h"
#include "hci_transport.h"
#include "l2cap.h"
#include "ble/sm.h"
#include "ble/att_server.h"
#include "ble/le_device_db.h"
#include "ble/att.h"
#include "user.h"

#define HEARTBEAT_PERIOD_MS 1000

/* @section Main Application Setup
 *
 * @text Listing MainConfiguration shows main application code.
 * It initializes L2CAP, the Security Manager and configures the ATT Server with the pre-compiled
 * ATT Database generated from $le_counter.gatt$. Finally, it configures the advertisements
 * and the heartbeat handler and boots the Bluetooth stack.
 * In this example, the Advertisement contains the Flags attribute and the device name.
 * The flag 0x06 indicates: LE General Discoverable Mode and BR/EDR not supported.
 */

/* LISTING_START(MainConfiguration): Init L2CAP SM ATT Server and start heartbeat timer */
static int  le_notification_enabled SEC(.non_volatile_ram);
static timer_source_t heartbeat SEC(.non_volatile_ram);
static btstack_packet_callback_registration_t hci_event_callback_registration SEC(.non_volatile_ram);
static btstack_packet_callback_registration_t sm_event_callback_registration SEC(.non_volatile_ram);
static hci_con_handle_t con_handle SEC(.non_volatile_ram);

static const char gap_device_name[] = "JL BLE 4.2";
static const uint8_t test_read_value[] = {0x01, 0x02};

#define TEST_BUF_SIZE  20
static u8 test_buf[TEST_BUF_SIZE] SEC(.non_volatile_ram) = {'a', 'b', 'c', 'd'};
static u8 ble_adv_flag SEC(.non_volatile_ram) = 0;

static void packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size);
static uint16_t att_read_callback(hci_con_handle_t con_handle, uint16_t att_handle, uint16_t offset, uint8_t *buffer, uint16_t buffer_size);
static int att_write_callback(hci_con_handle_t con_handle, uint16_t att_handle, uint16_t transaction_mode, uint16_t offset, uint8_t *buffer, uint16_t buffer_size);
static void beat(void);
static void heartbeat_handler(struct sys_timer *ts);

const uint8_t adv_data[] = {
    // Flags general discoverable, BR/EDR not supported
    0x02, 0x01, 0x06,
    // Name
    0x0b, 0x09, 'J', 'L', ' ', 'B', 'L', 'E', ' ', '4', '.', '2',
    0x03, 0x03, 0x12, 0x18,
};
const uint8_t adv_data_len = sizeof(adv_data);

static const uint8_t sm_min_key_size = 7;
static const uint8_t sm_encryption_flag = 0; ///0--not encrypt, 1--encrypt

static void app_packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size)
{
    /* puts("Layer - app_packet_handler \n"); */
    switch (packet_type) {
    case HCI_EVENT_PACKET:
        switch (hci_event_packet_get_type(packet)) {
        case SM_EVENT_JUST_WORKS_REQUEST: {
            sm_event_t *event = (sm_event_t *) packet;
            sm_just_works_confirm(event->addr_type, event->address);
        }
        printf("Just Works Confirmed.\n");
        break;
        case SM_EVENT_PASSKEY_DISPLAY_NUMBER:
            /* printf("Passkey display: %06u.\n", sm_event_passkey_display_number_get_passkey(packet)); */
            break;
        }
        break;
    }
}

static void sm_setup_init(void)
{
    //setup SM: Display only
    sm_init();
    sm_set_io_capabilities(IO_CAPABILITY_NO_INPUT_NO_OUTPUT);
    sm_set_authentication_requirements(SM_AUTHREQ_BONDING);
    sm_set_encryption_key_size_range(sm_min_key_size, 16);
    sm_set_request_SECurity(sm_encryption_flag);

    // register for HCI events
    /* hci_event_callback_registration.callback = &app_packet_handler; */
    /* hci_add_event_handler(&hci_event_callback_registration); */

    // register for SM events
    sm_event_callback_registration.callback = &app_packet_handler;
    sm_add_event_handler(&sm_event_callback_registration);


}


static void le_counter_setup(void)
{

    // register for HCI events
    hci_event_callback_registration.callback = &packet_handler;
    hci_add_event_handler(&hci_event_callback_registration);

    le_l2cap_init();

    // setup le device db
    le_device_db_init();

    // setup SM: Display only
    sm_setup_init();

    // setup ATT server
    att_server_init(profile_data, att_read_callback, att_write_callback);
    att_server_register_packet_handler(packet_handler);

    // setup advertisements
    uint16_t adv_int_min = 0x0140;
    uint16_t adv_int_max = 0x0140;
    uint8_t adv_type = 0;
    bd_addr_t null_addr;
    memset(null_addr, 0, 6);
    gap_advertisements_set_params(adv_int_min, adv_int_max, adv_type, 0, null_addr, 0x07, 0x00);
    gap_advertisements_set_data(adv_data_len, (uint8_t *) adv_data);
    gap_advertisements_enable(1);

    // set one-shot timer
    /* heartbeat.process = &heartbeat_handler; */
    /* btstack_run_loop_set_timer(&heartbeat, HEARTBEAT_PERIOD_MS); */
    /* btstack_run_loop_add_timer(&heartbeat); */
    sys_timer_register(&heartbeat, HEARTBEAT_PERIOD_MS, heartbeat_handler);

    // beat once
    beat();
}
/* LISTING_END */

/*
 * @section Heartbeat Handler
 *
 * @text The heartbeat handler updates the value of the single Characteristic provided in this example,
 * and request a ATT_EVENT_CAN_SEND_NOW to send a notification if enabled see Listing heartbeat.
 */

/* LISTING_START(heartbeat): Hearbeat Handler */
static int  counter SEC(.non_volatile_ram) = 0;
static char counter_string[20] SEC(.non_volatile_ram);
static int  counter_string_len SEC(.non_volatile_ram);

static void beat(void)
{
    counter++;
    counter_string_len = sprintf(counter_string, "counter %04u", counter);
    puts(counter_string);
}

static void heartbeat_handler(struct sys_timer *ts)
{
    static u32 count = 0;

    if (le_notification_enabled) {
        beat();
        att_server_request_can_send_now_event(con_handle);
    }
    /* btstack_run_loop_set_timer(ts, HEARTBEAT_PERIOD_MS); */
    /* btstack_run_loop_add_timer(ts); */

    sys_timer_register(&heartbeat, HEARTBEAT_PERIOD_MS, heartbeat_handler);
}
/* LISTING_END */

/*
 * @section Packet Handler
 *
 * @text The packet handler is used to:
 *        - stop the counter after a disconnect
 *        - send a notification when the requested ATT_EVENT_CAN_SEND_NOW is received
 */
static const uint8_t connection_update_enable = 0; ///0--disable, 1--enable
#define CONN_INTERVAL_MIN          50
#define CONN_INTERVAL_MAX          120
#define CONN_SUPERVISION_TIMEOUT   550

/* LISTING_START(packetHandler): Packet Handler */
static void packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size)
{
    switch (packet_type) {
    case HCI_EVENT_PACKET:
        switch (hci_event_packet_get_type(packet)) {

        case HCI_EVENT_CONNECTION_COMPLETE:
            break;

        case HCI_EVENT_LE_META:
            switch (hci_event_le_meta_get_subevent_code(packet)) {
            case HCI_SUBEVENT_LE_CONNECTION_COMPLETE: {
                con_handle = little_endian_read_16(packet, 4);
                printf("HCI_SUBEVENT_LE_CONNECTION_COMPLETE : %0x\n", con_handle);
                /* printf_buf((void*)connect_update_param_data,sizeof(connect_update_param_data)); */
                if (connection_update_enable) {
                    gap_request_connection_parameter_update(con_handle, CONN_INTERVAL_MIN, CONN_INTERVAL_MAX, 0, CONN_SUPERVISION_TIMEOUT);
                }
            }
            break;
            }
            break;

        case HCI_EVENT_DISCONNECTION_COMPLETE:
            puts("---ble disconnect!\n");
            le_notification_enabled = 0;
            con_handle = 0;
            break;

        case ATT_EVENT_CAN_SEND_NOW:
            if (le_notification_enabled) {
                puts("\n------notify send:");
                printf_buf((u8 *)counter_string, counter_string_len);
                att_server_notify(con_handle, ATT_CHARACTERISTIC_FF03_01_VALUE_HANDLE, (uint8_t *) counter_string, counter_string_len);
            }
            break;

        }
        break;
    }
}
/* LISTING_END */

/*
 * @section ATT Read
 *
 * @text The ATT Server handles all reads to constant data. For dynamic data like the custom characteristic, the registered
 * att_read_callback is called. To handle long characteristics and long reads, the att_read_callback is first called
 * with buffer == NULL, to request the total value length. Then it will be called again requesting a chunk of the value.
 * See Listing attRead.
 */

/* LISTING_START(attRead): ATT Read */

// ATT Client Read Callback for Dynamic Data
// - if buffer == NULL, don't copy data, just return size of value
// - if buffer != NULL, copy data and return number bytes copied
// @param offset defines start of attribute value
static uint16_t att_read_callback(hci_con_handle_t connection_handle, uint16_t att_handle, uint16_t offset, uint8_t *buffer, uint16_t buffer_size)
{

    uint16_t  att_value_len = 0;
    uint16_t handle = att_handle;

    /* printf("READ Callback, handle %04x, offset %u, buffer size %u\n", handle, offset, buffer_size); */

    printf("read_callback, handle= 0x%04x\n", handle);

    switch (handle) {
    case ATT_CHARACTERISTIC_GAP_DEVICE_NAME_01_VALUE_HANDLE:
        att_value_len = strlen(gap_device_name);

        if ((offset >= att_value_len) || (offset + buffer_size) > att_value_len) {
            break;
        }

        if (buffer) {
            if (att_value_len > buffer_size) {
                att_value_len = buffer_size;
            }
            memcpy(buffer, gap_device_name, att_value_len);
            puts("\n------read gap_name:");
            printf_buf(buffer, att_value_len);
        }
        break;

    case ATT_CHARACTERISTIC_FF01_01_VALUE_HANDLE:
        att_value_len = sizeof(test_read_value);
        if ((offset >= att_value_len) || (offset + buffer_size) > att_value_len) {
            break;
        }
        if (buffer) {
            if (att_value_len > buffer_size) {
                att_value_len = buffer_size;
            }

            memcpy(buffer, &test_read_value, att_value_len);
            puts("\n-----test_read:");
            printf_buf(buffer, att_value_len);
        }
        break;

    case ATT_CHARACTERISTIC_FF02_01_VALUE_HANDLE:
        if ((offset >= TEST_BUF_SIZE) || (offset + buffer_size) > TEST_BUF_SIZE) {
            break;
        }
        if (buffer) {
            if (att_value_len > buffer_size) {
                att_value_len = buffer_size;
            }

            att_value_len = TEST_BUF_SIZE - offset;
            memcpy(buffer, &test_buf[offset], att_value_len);
            puts("\n------read test_buf:");
            printf_buf(buffer, att_value_len);
        }
        break;

    default:
        break;
    }

    return att_value_len;

}


/* LISTING_END */


/*
 * @section ATT Write
 *
 * @text The only valid ATT write in this example is to the Client Characteristic Configuration, which configures notification
 * and indication. If the ATT handle matches the client configuration handle, the new configuration value is stored and used
 * in the heartbeat handler to decide if a new value should be sent. See Listing attWrite.
 */

/* LISTING_START(attWrite): ATT Write */
static int att_write_callback(hci_con_handle_t connection_handle, uint16_t att_handle, uint16_t transaction_mode, uint16_t offset, uint8_t *buffer, uint16_t buffer_size)
{
    int result = 0;

    u16 handle = att_handle;


    /* printf("WRITE Callback, handle %04x, mode %u, offset %u, data: ", handle, transaction_mode, offset); */

    printf("write_callback, handle= 0x%04x\n", handle);
    printf_buf(buffer, buffer_size);

    switch (handle) {
    case ATT_CHARACTERISTIC_FF03_01_CLIENT_CONFIGURATION_HANDLE:
        printf("\n------write ccc 0x%x\n", buffer[0]);
        /* con_handle = connection_handle; */
        le_notification_enabled = buffer[0];
        break;

    case ATT_CHARACTERISTIC_FF02_01_VALUE_HANDLE:
        if ((offset >= TEST_BUF_SIZE) || (offset + buffer_size) > TEST_BUF_SIZE) {
            result  = -1;
        } else {
            puts("\n------write test_buf:");
            printf_buf(buffer, buffer_size);
            memcpy(&test_buf[offset], buffer, buffer_size);
        }
        break;

    default:
        break;
    }
    return 0;
}


/* LISTING_END */



int btstack_main(void)
{
    le_hci_init(ble_hci_transport_h4_instance(), 0, 0, 0);

    le_btstack_memory_init();
    le_counter_setup();

    // turn on!
    le_hci_power_control(HCI_POWER_ON);

    con_handle = 0;
    ble_adv_flag = 1;

    return 0;
}

#include "key.h"
#include "input_task.h"

static void btstack_input_process(u32 input)
{
    printf("\nbtstack_input_process -%d-- ", input);
    switch (input) {
    case INPUT_AD_KEY9_SHORT:
        puts("INPUT_AD_KEY9_SHORT\n");
        if (con_handle) {
            hci_send_cmd(&hci_disconnect, con_handle, 0x13);
        }
        break;

    case INPUT_AD_KEY1_SHORT:
        if ((con_handle == 0) && (ble_adv_flag == 0)) {
            puts("ADV ENABLE\n");
            ble_adv_flag  = 1;
            hci_send_cmd(&hci_le_set_advertise_enable, 1);
        }
        break;

    case INPUT_AD_KEY2_SHORT:
        if ((con_handle == 0) && (ble_adv_flag == 1)) {
            puts("ADV DISABLE\n");
            ble_adv_flag  = 0;
            hci_send_cmd(&hci_le_set_advertise_enable, 0);
        }
        break;

    case INPUT_IO_KEY0_SHORT:
        puts("INPUT_IO_KEY0_SHORT\n");
        if (con_handle) {
            hci_send_cmd(&hci_disconnect, con_handle, 0x13);
        }
        break;
    }
}

void btstack_input_init(void)
{
    /* puts("btstack_input_init\n"); */
    input_register_hanler(btstack_input_process);
}



/* EXAMPLE_END */
