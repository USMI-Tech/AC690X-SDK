#include "typedef.h"
#include "printf.h"
#include "uart.h"
#include "rtos/os_api.h"
#include "task_schedule.h"
#include "init.h"



static void system_init(void)
{
    system_init_call();
}


void sys_main(void)
{
    system_init();

    if (!bt_power_is_poweroff_post()) {
        puts("\n--Idle--\n");
    }

    while (1) {
        TASK_DEBUG_IDLE;
        __asm__ volatile("idle");
        __asm__ volatile("nop");
        __asm__ volatile("nop");
    }
}


