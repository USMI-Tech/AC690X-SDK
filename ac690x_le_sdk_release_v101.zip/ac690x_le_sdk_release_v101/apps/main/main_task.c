#include "cpu.h"
#include <string.h>
#include "irq_interface.h"
#include "interrupt.h"
#include "printf.h"
#include "uart.h"
#include "init.h"
#include "task_schedule.h"
#include "rtos/os_api.h"



static void main_task(void *args)
{
    int msg_queue[6];

    if (!bt_power_is_poweroff_post()) {
        puts("\n**********");
        puts(TASK_NAME_MAIN);
        puts("**********\n");
    }

    while (1) {
        TASK_DEBUG_MAIN;
        /* puts("- main task"); */
        memset(msg_queue, 0x0, ARRAY_SIZE(msg_queue));
        os_taskq_pend(0, ARRAY_SIZE(msg_queue), msg_queue);

        switch (msg_queue[0]) {
        case 0:
            break;
        }
    }
}


static void main_task_init(void)
{
    u32 err;

    if (!bt_power_is_poweroff_post()) {
        puts("app initcall -- task main init\n");
    }

    err = os_task_create(main_task, (void *)0, TASK_PRIO_MAIN, 10, TASK_NAME_MAIN);

}
app_initcall(main_task_init);


