#include "typedef.h"
#include "printf.h"
#include "uart.h"
#include "init.h"
#include "stream/stream_dev.h"

struct stream_hdl {
    void *usb_speaker;
    void *decoder;
};

static struct stream_hdl hdl;

#define __this      (&hdl)

static
void stream_usb_speaker(void)
{
    __this->usb_speaker = stream_dev_open(48000, 2, STREAM_OUTPUT);

    u8 pcm_buf[192];
    u16 i;

    for (i = 0; i < ARRAY_SIZE(pcm_buf); i++) {
        pcm_buf[i] = i;
    }

    stream_dev_output(__this->usb_speaker, pcm_buf, 192);
}

static
void stream_task_init(void)
{
    app_stream_dev_init();
}
/* app_initcall(stream_task_init); */

