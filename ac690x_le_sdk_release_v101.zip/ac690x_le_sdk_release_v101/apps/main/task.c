#include "typedef.h"
#include "irq_interface.h"
#include "interrupt.h"
#include "printf.h"
#include "uart.h"
#include "init.h"
#include "task_schedule.h"
#include "rtos/os_api.h"


static OS_SEM sem1;
static OS_SEM sem2;

static OS_MSGQ msgq;
void *msg[40];

static void test_stack(void)
{
    u32 tmp;
    u16 i;
    u8 buf[512];

    for (i = 0; i < 512; i++) {
        buf[i] = i;
    }
    printf("buf = 0x%x\n", buf[0]);

    asm("mov %0, sp" : "=r"(tmp));
    printf("sp = 0x%x\n", tmp);

    puts("Vaddr --- \n");
    printf_buf(0x81000 - 0x200, 0x10);
    printf_buf(0x81000 - 0x200 - 0x10, 0x10);
    printf_buf(0x10 * 0x200, 0x10);
    puts("Paddr --- \n");
    printf_buf(0x8 * 0x200 - 0x10, 0x10);
}

static void task1(void)
{
    puts("\n**********");
    puts(TASK_NAME_TASK1);

    while (1) {
        IO_DEBUG_TOGGLE(A, 1);

        u32 tmp;
        ///printf rets & reti
        puts("\nA1");
        /* test_stack(); */

        OSTimeDly(5);
        puts("A2\n");

        os_sem_pend(&sem1, 0);
        os_sem_post(&sem2);
        /* os_taskq_pend(0, ARRAY_SIZE(msg), msg); */

        /* switch(msg[0]) */
        /* { */
        /* default: */
        /* break; */
        /* } */
    }
}

static void task2(void)
{
    puts("\n**********");
    puts(TASK_NAME_TASK2);
    while (1) {
        IO_DEBUG_TOGGLE(A, 2);

        u32 tmp;
        puts("\nB1");
        asm("mov %0, sp" : "=r"(tmp));
        printf("sp = 0x%x\n", tmp);
        os_time_dly(10);
        puts("B2\n");

        os_sem_pend(&sem2, 0);
        os_sem_post(&sem1);
        /* os_taskq_pend(0, ARRAY_SIZE(msg), msg); */

        /* switch(msg[0]) */
        /* { */
        /* default: */
        /* break; */
        /* } */
    }
}


static void task3(void)
{
    puts("\n**********");
    puts(TASK_NAME_TASK1);
    while (1) {
        u8 res;

        puts("wait q...\n");
        /* void *a; */
        /* res = os_q_pend(&msgq, 0, a); */
        u32 a;
        res = os_q_pend(&msgq, 0, &a);
        if (res == OS_NO_ERR) {
            printf("pend res %x - %x\n", res, a);
        }
        /* res = os_taskq_pend(0, 3, msg); */
        printf_buf(msg, ARRAY_SIZE(msg));
    }
}

static void task4(void)
{
    puts("\n**********");
    puts(TASK_NAME_TASK2);
    while (1) {

        u8 res;
        puts("post  q ...\n");
        u32 a = 0x55aa;
        res = os_q_post(&msgq, a);
        printf_buf(msg, ARRAY_SIZE(msg));
        res = os_q_post(&msgq, a);
        printf_buf(msg, ARRAY_SIZE(msg));
        /* res = os_taskq_post(TASK_NAME_TASK1, 3, msg[0], msg[1], msg[2]); */
        printf("post res %x - %x\n", res, a);
        os_time_dly(100);
    }
}


static void task_init(void)
{
    u32 err;

    puts("app initcall -- task init\n");

    err = os_sem_create(&sem1, 1);
    err = os_q_create(&msgq, msg, ARRAY_SIZE(msg));
    printf("create err %x-%x-%x\n", err, ARRAY_SIZE(msg), sizeof(void *) + sizeof(unsigned short) * 4);

    err = os_task_create(task3, (void *)0, TASK_PRIO_TASK1, 10, TASK_NAME_TASK1);

    err = os_sem_create(&sem2, 1);
    err = os_task_create(task4, (void *)0, TASK_PRIO_TASK2, 10, TASK_NAME_TASK2);
}
/* app_initcall(task_init); */


