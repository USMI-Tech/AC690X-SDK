#include "cpu.h"
#include "init.h"
#include "vm.h"
#include "flash_cfg.h"
#include "icache_interface.h"

#define FLASH_SIZE		(2*1024*1024L)
#define VM_SIZE			(64*1024L)


static u8 vm_debug(void)
{
    puts("\n======================TEST for VM====================\n");

    u8 *buf = 0;;
    u8 buf_cnt = 0;
    u8 hd_cnt = 0;
    u32 ret;

    while (1) {
        if (buf_cnt >= 128 + 1) {
            buf_cnt = 0;
            hd_cnt++;
            if (hd_cnt >= 2) {
                puts("\n======================TEST OVER====================\n");
                vm_eraser();
                return 1;
            }
        }

        buf = malloc(++buf_cnt);
        ASSERT(buf);
        printf("hd_cnt=%d    buf_cnt=%d\n", hd_cnt, buf_cnt);

        memset(buf, 0xfe, buf_cnt);
        vm_hdl vm_ptr = vm_open(hd_cnt, buf_cnt);

        ret = vm_write(vm_ptr, buf);
        if (ret != buf_cnt) {
            puts("vm_write err\n");
            printf("ret = %d\n", ret);
            goto __err;
        }

        memset(buf, 0x00, buf_cnt);
        ret = vm_read(vm_ptr, buf);
        if (ret != buf_cnt) {
            puts("vm_read err\n");
            printf("ret = %d\n", ret);
            goto __err;
        }
        /* printf_buf(buf, buf_cnt); */
        vm_close(vm_ptr);
        free(buf);
    }

__err:
    puts("\n======================TEST ERR====================\n");
    free(buf);
    return 0;
}

extern u32 args[3];

APP_USE_FLASH_SYS_CFG app_use_flash_cfg;

static void vm_task_init(void)
{
    u32 err;

    FLASH_SYS_CFG *sys_cfg = (void *)(args[0] + FLASH_BASE_ADDR);

    puts("app initcall -- vm task init\n");

    printf("base0 = %x\n", args[0]);
    printf("base1 = %x\n", args[1]);
    printf("base2 = %x\n", args[2]);

    err = vm_init(sys_cfg->flash_cfg.flash_size/*FLASH_SIZE*/ - VM_SIZE, VM_SIZE, sys_cfg->flash_cfg.flash_base, sys_cfg->flash_cfg.spi_run_mode, 1);

    printf("init_ret = %d\n", err);
    ASSERT(!err);

    if (vm_debug) {
        err = vm_debug();
        ASSERT(err);
    }

}
/* app_initcall(vm_task_init); */

