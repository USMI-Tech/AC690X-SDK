/*********************************************************************************************
    *   Filename        : ui_interface.h

    *   Description     : 根据不同显示屏选择不同界面映射关系

    *   Author          : Bingquan

    *   Email           : bingquan_cai@zh-jieli.com

    *   Last modifiled  : 2016-08-18 01:58

    *   Copyright:(c)JIELI  2011-2016  @ , All Rights Reserved.
*********************************************************************************************/
#ifndef __UI_INTERFACE_H__
#define __UI_INTERFACE_H__

#include "typedef.h"
#include "list.h"

enum {
    OLED_SHOW_DATE = 0,            /* 0*/
    OLED_SHOW_SYS_INFO,            /* 1*/
    OLED_SHOW_FIND_MOBILE,         /* 2*/
    OLED_SHOW_SETTING,             /* 3*/

    OLED_SHOW_MESSAGE_BOX,         /* 4*/

    OLED_SHOW_HEART_RATE,          /* 5*/

    OLED_SHOW_BLUETOOTH_STATE,     /* 6*/
    OLED_SHOW_WEATHER,             /* 7*/
    OLED_SHOW_AIR_CONDITION,       /* 8*/

    OLED_SHOW_STEPS,               /* 9*/
    OLED_SHOW_CALO,                /*10*/
    OLED_SHOW_DISTANCE,            /*11*/

    OLED_SHOW_MESSAGE,             /*12*/

    //Event driven
    OLED_SHOW_ALARM,
    OLED_SHOW_ALARM_REQUSET,

    OLED_SHOW_SETTING_REQUSET,
    OLED_SHOW_HEART_RATE_TESTING,
};

#define     UI_SHOW_DATE                OLED_SHOW_DATE

#define     UI_SHOW_STEPS               OLED_SHOW_STEPS
#define     UI_SHOW_CALO                OLED_SHOW_CALO
#define     UI_SHOW_DISTANCE            OLED_SHOW_DISTANCE

#define     UI_SHOW_HEART_RATE          OLED_SHOW_HEART_RATE

#define     UI_SHOW_WEATHER             OLED_SHOW_WEATHER

#define     UI_SHOW_MESSAGE             OLED_SHOW_MESSAGE

#define     UI_SHOW_SYS_INFO            OLED_SHOW_SYS_INFO
#define     UI_SHOW_FIND_MOBILE         OLED_SHOW_FIND_MOBILE
#define     UI_SHOW_SETTING             OLED_SHOW_SETTING

#define     UI_SHOW_MESSAGE_BOX         OLED_SHOW_MESSAGE_BOX
#define     UI_SHOW_AIR_CONDITION       OLED_SHOW_AIR_CONDITION

#define     UI_SHOW_BLUETOOTH_STATE     OLED_SHOW_BLUETOOTH_STATE

struct ui_interface {
    u8 id;
    void (*func)(void);
    struct list_head entry;
    struct list_head child;
};


struct ui_driver {
    void *(*init)(void);
    void (*show)(u8);
    void (*ioctrl)(u8, ...);
};

#define REGISTER_UI_DRIVER(drv) \
	const struct ui_driver *__ui_ops \
			SEC_USED(.text) = &drv

extern const struct ui_driver *__ui_ops;

#endif
