#include "typedef.h"
#include "printf.h"
#include "uart.h"
#include "init.h"
#include "ui_interface.h"
#include "ui_oled_debug.h"

struct ui_oled_hdl {
    void *priv;
    struct list_head head;
    struct ui_interface *curr_ui;
    u8 current_ui_id;
};

static struct ui_oled_hdl   hdl;

#define __this      (&hdl)

static void __oled_show_date(void)
{
    /*-TODO-*/
    /* __oled_ops-> */
}

static void __oled_show_steps(void)
{
    /*-TODO-*/

}

static struct ui_interface oled_interface[] = {
    //X - 0
    [UI_SHOW_DATE] = {
        .id = UI_SHOW_DATE,
        .func = __oled_show_date,
    },

    //X - 0 / Y - 0
    [UI_SHOW_SYS_INFO] = {
        .id = UI_SHOW_SYS_INFO,
        .func = NULL,
    },
    //X - 0 / Y - 1
    [UI_SHOW_FIND_MOBILE] = {
        .id = UI_SHOW_FIND_MOBILE,
        .func = NULL,
    },
    //X - 0 / Y - 2
    [UI_SHOW_SETTING] = {
        .id = UI_SHOW_SETTING,
        .func = NULL,
    },

    //X - 1
    [UI_SHOW_MESSAGE] = {
        .id = UI_SHOW_MESSAGE,
        .func = NULL,
    },

    //X - 2
    [UI_SHOW_HEART_RATE] = {
        .id = UI_SHOW_HEART_RATE,
        .func = NULL,
    },

    [UI_SHOW_BLUETOOTH_STATE] = {
        .id = UI_SHOW_BLUETOOTH_STATE,
        .func = NULL,
    },
    //X - 2
    [UI_SHOW_WEATHER] = {
        .id = UI_SHOW_WEATHER,
        .func = NULL,
    },

    [UI_SHOW_AIR_CONDITION] = {
        .id = UI_SHOW_AIR_CONDITION,
        .func = NULL,
    },

    //X - 3
    [UI_SHOW_STEPS] = {
        .id = UI_SHOW_STEPS,
        .func = __oled_show_steps,
    },
    //X - 3 / Y - 0
    [UI_SHOW_CALO] = {
        .id = UI_SHOW_CALO,
        .func = NULL,
    },
    //X - 3 / Y - 1
    [UI_SHOW_DISTANCE] = {
        .id = UI_SHOW_DISTANCE,
        .func = NULL,
    },
};

void oled_window_move(void)
{

}

void oled_window_next(void)
{

}

void oled_window_prev(void)
{

}

void oled_window_up(void)
{

}

void oled_window_down(void)
{

}



void ui_oled_show(u8 ui_id)
{
    u8 index;

    oled_interface[ui_id].func();
}

static void ui_oled_debug(void)
{
    struct ui_interface *p;

    uio_puts("\nUI loop");
    list_for_each_entry(p, &__this->head, entry) {
        uio_printf("\nUI-X id : %d", p->id);
        struct ui_interface *n;
        list_for_each_entry(n, &p->child, child) {
            uio_printf(" - UI-Y id : %d", n->id);
        }
    }
}

static void ui_oled_bluetooth_state(u8 state)
{
    //bluetooth state change
    if (state == 0) {
        list_add(&oled_interface[OLED_SHOW_FIND_MOBILE].child, &oled_interface[OLED_SHOW_SYS_INFO].child);

        //replace element
        list_add(&oled_interface[OLED_SHOW_WEATHER].entry, &oled_interface[OLED_SHOW_BLUETOOTH_STATE].entry);
        list_del(&oled_interface[OLED_SHOW_BLUETOOTH_STATE].entry);

        INIT_LIST_HEAD(&oled_interface[OLED_SHOW_WEATHER].child);
        list_add_tail(&oled_interface[OLED_SHOW_AIR_CONDITION].child, &oled_interface[OLED_SHOW_WEATHER].child);
    } else {
        list_del(&oled_interface[OLED_SHOW_FIND_MOBILE].child);

        //replace element
        list_add(&oled_interface[OLED_SHOW_BLUETOOTH_STATE].entry, &oled_interface[OLED_SHOW_WEATHER].entry);
        list_del(&oled_interface[OLED_SHOW_WEATHER].entry);
    }
}

void ui_oled_message_box_add(struct ui_interface *message)
{
    struct ui_interface *p, *n;

    list_for_each_entry_safe(p, n, &__this->head, entry) {
        if (p->id == UI_SHOW_MESSAGE_BOX) {
            list_add_tail(&message->child, &p->child);
            return;
        }
    }
    //No Message
    list_add_tail(&message->entry, &oled_interface[UI_SHOW_DATE].entry);
}

void ui_oled_message_box_delete(struct ui_interface *message)
{
    struct ui_interface *p, *n;

    list_for_each_entry_safe(p, n, &__this->head, entry) {
        if (p->id == UI_SHOW_MESSAGE_BOX) {
            list_del(&p->child);
            return;
        }
    }

    list_add_tail(&message->entry, &oled_interface[UI_SHOW_DATE].entry);
}


static void ui_oled_init(void)
{
    u8 index;

    //UI 布局
    for (index = 0; index < ARRAY_SIZE(oled_interface); index++) {
        INIT_LIST_HEAD(&oled_interface[index].child);
    }

    //Main menu
    INIT_LIST_HEAD(&__this->head);
    list_add_tail(&oled_interface[OLED_SHOW_DATE].entry, &__this->head);
    list_add_tail(&oled_interface[OLED_SHOW_HEART_RATE].entry, &__this->head);
    list_add_tail(&oled_interface[OLED_SHOW_BLUETOOTH_STATE].entry, &__this->head);
    list_add_tail(&oled_interface[OLED_SHOW_STEPS].entry, &__this->head);

    INIT_LIST_HEAD(&oled_interface[OLED_SHOW_DATE].child);
    list_add_tail(&oled_interface[OLED_SHOW_SYS_INFO].child, &oled_interface[OLED_SHOW_DATE].child);
    list_add_tail(&oled_interface[OLED_SHOW_SETTING].child, &oled_interface[OLED_SHOW_DATE].child);

    INIT_LIST_HEAD(&oled_interface[OLED_SHOW_STEPS].child);
    list_add_tail(&oled_interface[OLED_SHOW_CALO].child, &oled_interface[OLED_SHOW_STEPS].child);
    list_add_tail(&oled_interface[OLED_SHOW_DISTANCE].child, &oled_interface[OLED_SHOW_STEPS].child);

    ui_oled_debug();

    ui_oled_bluetooth_state(0);
    ui_oled_debug();

    ui_oled_bluetooth_state(1);
    ui_oled_debug();
}



struct ui_driver ui_oled_ins = {
    .init = ui_oled_init,
    .show = ui_oled_show,
};
REGISTER_UI_DRIVER(ui_oled_ins);
