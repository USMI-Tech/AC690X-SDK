#ifndef _UI_OLED_H_
#define _UI_OLED_H_

#define UI_OLED_DEG

#ifdef UI_OLED_DEG
#define uio_puts           puts
#define uio_u32hex0        put_u32hex0
#define uio_u32hex         put_u32hex
#define uio_printf         printf

#define uio_without_lock0  printf_without_lock
#define uio_without_lock1  puts_without_lock
#define uio_u16hex         put_u16hex
#define uio_u8hex0         put_u8hex0
#define uio_u8hex          put_u8hex
#define uio_buf            put_buf
#define uio_buf0           printf_buf
#define uio_char           putchar
#define uio_byte           putbyte
#else
#define uio_puts(...)
#define uio_u32hex0(...)
#define uio_u32hex(...)
#define uio_printf(...)

#define uio_without_lock0(...)
#define uio_without_lock1(...)
#define uio_u16hex(...)
#define uio_u8hex0(...)
#define uio_u8hex(...)
#define uio_buf(...)
#define uio_buf0(...)
#define uio_char(...)
#define uio_byte(...)
#endif


#endif

