#include "typedef.h"
#include "printf.h"
#include "uart.h"
#include "init.h"
#include "task_schedule.h"
#include "ui_interface.h"
#include "ui_task.h"



struct ui_hdl {
    void *ui_set;
    u16 ftps;

    u8 fade;
    u8 fade_speed;
};

static struct ui_hdl    hdl;

#define __this      (&hdl)


/*
 *  Features:
 *
 *  1.Pic display
 *
 *  2.Pics[] display in ftps
 *
 *  3.Pic switch fade
 *
 *  4.Pic move (up/down/left/right)
 *
 *  5.Pic rolling vertical <-> horizon
 */

static void ui_display_thread(void)
{
    u8 msg_q[6];
    puts("\n**********");
    puts(TASK_NAME_UI);
    puts("**********\n");

    while (1) {
        u8 ui_id;

        /* memset(msg_q, ARRAY_SIZE(msg_q)); */
        os_taskq_pend(0, ARRAY_SIZE(msg_q), msg_q);
        printf("ui display task msg : %d\n", msg_q[0]);

        /* __ui_ops->show(ui_id); */

        OSTimeDly(__this->ftps * 100);
    }
}

//UI-1 func
static void ui_init(void)
{
    /* __ui_ops->init(); */

    __this->ftps = 5;
    u8 err;

    err = os_task_create(ui_display_thread, (void *)0, TASK_PRIO_UI, 10, TASK_NAME_UI);

    /* __ui_ops->show(UI_SHOW_DATE); */
}
/* app_initcall(ui_init); */

