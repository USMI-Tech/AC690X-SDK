/*********************************************************************************************
    *   Filename        : le_controller.h

    *   Description     :

    *   Author          : Bingquan

    *   Email           : bingquan_cai@zh-jieli.com

    *   Last modifiled  : 2017-02-03 17:38

    *   Copyright:(c)JIELI  2011-2016  @ , All Rights Reserved.
*********************************************************************************************/

#ifndef __LE_CONTROLLER_H
#define __LE_CONTROLLER_H

#include "typedef.h"
#include <utils.h>

void bt_osc_internal_cfg(u8 sel_l, u8 sel_r);

int le_controller_set_mac(bd_addr_t *addr);

int le_controller_init(void);

#endif
