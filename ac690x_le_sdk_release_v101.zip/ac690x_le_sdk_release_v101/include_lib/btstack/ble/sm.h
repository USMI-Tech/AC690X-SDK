/*********************************************************************************************
    *   Filename        : sm.h

    *   Description     :

    *   Author          : Bingquan

    *   Email           : bingquan_cai@zh-jieli.com

    *   Last modifiled  : 2017-01-17 15:16

    *   Copyright:(c)JIELI  2011-2016  @ , All Rights Reserved.
*********************************************************************************************/

#ifndef __SM_H
#define __SM_H

#include <utils.h>
#include <btstack.h>
#include <stdint.h>

#if defined __cplusplus
extern "C" {
#endif


// Bluetooth Spec definitions
    typedef enum {
        SM_CODE_PAIRING_REQUEST = 0X01,
        SM_CODE_PAIRING_RESPONSE,
        SM_CODE_PAIRING_CONFIRM,
        SM_CODE_PAIRING_RANDOM,
        SM_CODE_PAIRING_FAILED,
        SM_CODE_ENCRYPTION_INFORMATION,
        SM_CODE_MASTER_IDENTIFICATION,
        SM_CODE_IDENTITY_INFORMATION,
        SM_CODE_IDENTITY_ADDRESS_INFORMATION,
        SM_CODE_SIGNING_INFORMATION,
        SM_CODE_SECURITY_REQUEST
    } SECURITY_MANAGER_COMMANDS;

// IO Capability Values
    typedef enum {
        IO_CAPABILITY_DISPLAY_ONLY = 0,
        IO_CAPABILITY_DISPLAY_YES_NO,
        IO_CAPABILITY_KEYBOARD_ONLY,
        IO_CAPABILITY_NO_INPUT_NO_OUTPUT,
        IO_CAPABILITY_KEYBOARD_DISPLAY, // not used by secure simple pairing
    } io_capability_t;


// Authentication requirement flags
#define SM_AUTHREQ_NO_BONDING        0x00
#define SM_AUTHREQ_BONDING           0x01
#define SM_AUTHREQ_MITM_PROTECTION   0x04
#define SM_AUTHREQ_SECURE_CONNECTION 0x08
#define SM_AUTHREQ_KEYPRESS          0x10

// Key distribution flags used by spec
#define SM_KEYDIST_ENC_KEY  0x01
#define SM_KEYDIST_ID_KEY   0x02
#define SM_KEYDIST_SIGN     0x04
#define SM_KEYDIST_LINK_KEY 0x08

// Key distribution flags used internally
#define SM_KEYDIST_FLAG_ENCRYPTION_INFORMATION       0x01
#define SM_KEYDIST_FLAG_MASTER_IDENTIFICATION        0x02
#define SM_KEYDIST_FLAG_IDENTITY_INFORMATION         0x04
#define SM_KEYDIST_FLAG_IDENTITY_ADDRESS_INFORMATION 0x08
#define SM_KEYDIST_FLAG_SIGNING_IDENTIFICATION       0x10

// STK Generation Methods
#define SM_STK_GENERATION_METHOD_JUST_WORKS 0x01
#define SM_STK_GENERATION_METHOD_OOB        0x02
#define SM_STK_GENERATION_METHOD_PASSKEY    0x04

// Pairing Failed Reasons
#define SM_REASON_RESERVED                     0x00
#define SM_REASON_PASSKEYT_ENTRY_FAILED        0x01
#define SM_REASON_OOB_NOT_AVAILABLE            0x02
#define SM_REASON_AUTHENTHICATION_REQUIREMENTS 0x03
#define SM_REASON_CONFIRM_VALUE_FAILED         0x04
#define SM_REASON_PAIRING_NOT_SUPPORTED        0x05
#define SM_REASON_ENCRYPTION_KEY_SIZE          0x06
#define SM_REASON_COMMAND_NOT_SUPPORTED        0x07
#define SM_REASON_UNSPECIFIED_REASON           0x08
#define SM_REASON_REPEATED_ATTEMPTS            0x09
// also, invalid parameters
// and reserved

// Only for PTS testing
    void sm_test_set_irk(sm_key_t irk);

    typedef struct {
        linked_item_t  item;
        bd_addr_t      address;
        bd_addr_type_t address_type;
    } sm_lookup_entry_t;

    /* API_START */

    /**
     * @brief Security Manager event
     */
    typedef struct sm_event {
        //base info
        uint8_t   type;                 ///< See <btstack/hci_cmds.h> SM_...
        uint8_t   addr_type;
        uint8_t   size;
        bd_addr_t address;
        hci_con_handle_t con_handle;
        //extend info
        union {
            uint32_t  passkey;              ///< only used for SM_EVENT_PASSKEY_DISPLAY_NUMBER
            uint16_t  le_device_db_index;   ///< only used for SM_IDENTITY_RESOLVING_..
            uint8_t   authorization_result; ///< only use for SM_EVENT_AUTHORIZATION_RESULT
        };
    } sm_event_t;

    /**
     * @brief Initializes the Security Manager, connects to L2CAP
     */
    void sm_init(void);

    /**
     * @brief Set secret ER key for key generation as described in Core V4.0, Vol 3, Part G, 5.2.2
     * @param er
     */
    void sm_set_er(sm_key_t er);

    /**
     * @brief Set secret IR key for key generation as described in Core V4.0, Vol 3, Part G, 5.2.2
     */
    void sm_set_ir(sm_key_t ir);

    /**
     *
     * @brief Registers OOB Data Callback. The callback should set the oob_data and return 1 if OOB data is availble
     * @param get_oob_data_callback
     */
    void sm_register_oob_data_callback(int (*get_oob_data_callback)(uint8_t addres_type, bd_addr_t addr, uint8_t *oob_data));

    /**
     *
     * @brief Registers packet handler. Called by att_server.c
     */
// void sm_register_packet_handler(btstack_packet_handler_t handler);

    /**
     * @brief Limit the STK generation methods. Bonding is stopped if the resulting one isn't in the list
     * @param OR combination of SM_STK_GENERATION_METHOD_
     */
    void sm_set_accepted_stk_generation_methods(uint8_t accepted_stk_generation_methods);

    /**
     * @brief Set the accepted encryption key size range. Bonding is stopped if the result isn't within the range
     * @param min_size (default 7)
     * @param max_size (default 16)
     */
    void sm_set_encryption_key_size_range(uint8_t min_size, uint8_t max_size);

    /**
     * @brief Sets the requested authentication requirements, bonding yes/no, MITM yes/no
     * @param OR combination of SM_AUTHREQ_ flags
     */
    void sm_set_authentication_requirements(uint8_t auth_req);

    /**
     * @brief Sets the available IO Capabilities
     * @param IO_CAPABILITY_
     */
    void sm_set_io_capabilities(io_capability_t io_capability);

    /**
     * @brief Let Peripheral request an encrypted connection right after connecting
     * @note Not used normally. Bonding is triggered by access to protected attributes in ATT Server
     */
    void sm_set_request_security(int enable);

    /**
     * @brief Trigger Security Request
     * @note Not used normally. Bonding is triggered by access to protected attributes in ATT Server
     */
    void sm_send_security_request(uint16_t handle);

    /**
     * @brief Decline bonding triggered by event before
     * @param addr_type and address
     */
    void sm_bonding_decline(uint8_t addr_type, bd_addr_t address);

    /**
     * @brief Confirm Just Works bonding
     * @param addr_type and address
     */
    void sm_just_works_confirm(uint8_t addr_type, bd_addr_t address);

    void sm_just_works_confirm1(hci_con_handle_t con_handle);
    /**
     * @brief Reports passkey input by user
     * @param addr_type and address
     * @param passkey in [0..999999]
     */
    void sm_passkey_input(uint8_t addr_type, bd_addr_t address, uint32_t passkey);

    /**
     *
     * @brief Get encryption key size.
     * @param addr_type and address
     * @return 0 if not encrypted, 7-16 otherwise
     */
    int sm_encryption_key_size(uint8_t addr_type, bd_addr_t address);

    /**
     * @brief Get authentication property.
     * @param addr_type and address
     * @return 1 if bonded with OOB/Passkey (AND MITM protection)
     */
    int sm_authenticated(uint8_t addr_type, bd_addr_t address);

    /**
     * @brief Queries authorization state.
     * @param addr_type and address
     * @return authorization_state for the current session
     */
    authorization_state_t sm_authorization_state(uint8_t addr_type, bd_addr_t address);

    /**
     * @brief Used by att_server.c to request user authorization.
     * @param addr_type and address
     */
    void sm_request_pairing(uint8_t addr_type, bd_addr_t address);

    /**
     * @brief Report user authorization decline.
     * @param addr_type and address
     */
    void sm_authorization_decline(uint8_t addr_type, bd_addr_t address);

    /**
     * @brief Report user authorization grant.
     * @param addr_type and address
     */
    void sm_authorization_grant(uint8_t addr_type, bd_addr_t address);

    /**
     * @brief Support for signed writes, used by att_server.
     * @note Message and result are in little endian to allows passing in ATT PDU without flipping.
     * @note calculated hash in done_callback is big endian
     */
    int  sm_cmac_ready(void);
    void sm_cmac_start(sm_key_t k, uint8_t opcode, uint16_t attribute_handle, uint16_t message_len, uint8_t *message, uint32_t sign_counter, void (*done_handler)(uint8_t hash[8]));

    /*
     * @brief Match address against bonded devices
     * @return 0 if successfully added to lookup queue
     * @note Triggers SM_IDENTITY_RESOLVING_* events
     */
    int sm_address_resolution_lookup(uint8_t addr_type, bd_addr_t addr);

    /**
     * @brief Identify device in LE Device DB.
     * @param handle
     * @return index from le_device_db or -1 if not found/identified
     */
    int sm_le_device_index(uint16_t handle);
    /* API_END */

// testing only
    void sm_test_use_fixed_local_csrk(void);

#if defined __cplusplus
}
#endif

#endif // __SM_H
