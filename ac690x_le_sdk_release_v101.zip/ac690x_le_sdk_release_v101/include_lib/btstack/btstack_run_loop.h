/*********************************************************************************************
    *   Filename        : btstack_run_loop.h

    *   Description     :

    *   Author          : Bingquan

    *   Email           : bingquan_cai@zh-jieli.com

    *   Last modifiled  : 2017-01-17 15:13

    *   Copyright:(c)JIELI  2011-2016  @ , All Rights Reserved.
*********************************************************************************************/
#ifndef BTSTACK_RUN_LOOP_H
#define BTSTACK_RUN_LOOP_H


#include "thread.h"
#include "sys_timer.h"


typedef struct sys_timer timer_source_t ;












#endif

