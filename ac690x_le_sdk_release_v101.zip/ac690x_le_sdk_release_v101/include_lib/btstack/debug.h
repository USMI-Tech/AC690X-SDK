/*********************************************************************************************
    *   Filename        : debug.h

    *   Description     :

    *   Author          : Bingquan

    *   Email           : bingquan_cai@zh-jieli.com

    *   Last modifiled  : 2017-01-17 15:14

    *   Copyright:(c)JIELI  2011-2016  @ , All Rights Reserved.
*********************************************************************************************/

/*
 *  debug.h
 *
 *  allow to funnel debug & error messages
 */

#ifndef __DEBUG_H
#define __DEBUG_H

#include "btstack-config.h"
#include "btstack_defines.h"
#include "hci_dump.h"

//#include <stdio.h>

#ifdef __AVR__
#include <avr/pgmspace.h>
#endif

#ifndef EMBEDDED
// Avoid complaints of unused arguments when log levels are disabled.
static inline void __log_unused(const char *format, ...)
{
}
#else
#define __log_unused(...)
#endif

#ifdef __AVR__
#define HCI_DUMP_LOG(format, ...) hci_dump_log_P(PSTR(format), ## __VA_ARGS__)
#define PRINTF(format, ...)       printf_P(PSTR(format), ## __VA_ARGS__)
#else
#define HCI_DUMP_LOG(format, ...) hci_dump_log(format, ## __VA_ARGS__)
#define PRINTF(format, ...)       printf(format, ## __VA_ARGS__)
#endif

#ifdef ENABLE_LOG_DEBUG
#ifdef HAVE_HCI_DUMP
#define log_debug(format, ...)  HCI_DUMP_LOG(format,  ## __VA_ARGS__)
#else
#define log_debug(format, ...)  PRINTF(format "\n",  ## __VA_ARGS__)
#endif
#else
#define log_debug(...) __log_unused(__VA_ARGS__)
#endif

#ifdef ENABLE_LOG_INFO
#ifdef HAVE_HCI_DUMP
#define log_info(format, ...)  HCI_DUMP_LOG(format,  ## __VA_ARGS__)
#else
#define log_info(format, ...)  PRINTF(format "\n",  ## __VA_ARGS__)
#endif
#else
#define log_info(...) __log_unused(__VA_ARGS__)
#endif

#ifdef ENABLE_LOG_ERROR
#ifdef HAVE_HCI_DUMP
#define log_error(format, ...)  HCI_DUMP_LOG(format,  ## __VA_ARGS__)
#else
#define log_error(format, ...)  PRINTF(format "\n",  ## __VA_ARGS__)
#endif
#else
#define log_error(...) __log_unused(__VA_ARGS__)
#endif

/**
 * @brief Log Security Manager key via log_info
 * @param key to log
 */
void log_info_key(const char *name, sm_key_t key);

/**
 * @brief Hexdump via log_info
 * @param data
 * @param size
 */
void log_info_hexdump(const void *data, int size);

#endif // __DEBUG_H
