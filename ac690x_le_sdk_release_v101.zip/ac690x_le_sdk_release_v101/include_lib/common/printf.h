#ifndef _PRINTF_DEFINED_
#define _PRINTF_DEFINED_


int printf(const char *format, ...);

int sprintf(char *out, const char *format, ...);

/* int puts( char *out); */


#endif
