#ifndef _CLOCK_API_H_
#define _CLOCK_API_H_

#include "typedef.h"





/********************************************************************************/
/*
 *      API
 */
void clock_init(u8 sys_in, u32 input_freq, u32 out_freq);

void clock_set_sys_freq(u32 freq);

u32 clock_get_sys_freq(void);

void clock_set_lsb_freq(u32 freq);

u32 clock_get_lsb_freq(void);

u32 clock_get_sfc_freq(void);



#endif
