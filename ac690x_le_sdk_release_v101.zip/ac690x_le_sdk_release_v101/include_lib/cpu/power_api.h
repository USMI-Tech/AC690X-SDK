#ifndef _POWER_H_
#define _POWER_H_

#include "typedef.h"
#include "power_interface.h"
//API
#define AT_VOLATILE_RAM             AT(.volatile_ram)
#define AT_VOLATILE_RAM_CODE        AT(.volatile_ram_code)
#define AT_NON_VOLATILE_RAM         AT(.non_volatile_ram)
#define AT_NON_VOLATILE_RAM_CODE    AT(.non_volatile_ram_code)

#define BT_SLEEP_EN                 BIT(2)
#define BT_SLEEP_TIMEOUT_MIN        (50*625L)  //间隔至少要50slot以上才进入power down

#define BT_DEEP_SLEEP_EN            BIT(1)
#define BT_DEEP_SLEEP_TIMEOUT_MIN   (60*625L)  //间隔至少要60slot以上才进入power off



typedef enum {
    BT_OSC = 0,
    RTC_OSCH,
    RTC_OSCL,
} OSC_TYPE;

struct bt_low_power_param {
    OSC_TYPE osc_type;
    u32 osc_hz;
    u8 is_use_PR;
    u8 delay_us;
    u8 config;
    u8 d2sh_dis_sw;
    u32(*lowpower_fun)(void);
    void (*poweroff_fun)(void);
};



enum {
    POWER_OSC_INFO,
    POWER_RTC_PORT,
    POWER_DELAY_US,
    POWER_WAKE_IO_CALLBACK,
    POWER_LWR_DEAL_CALLBACK,
    POWER_SET_POWEROFF_FUN,
    POWER_SET_RESET_MASK,
    POWER_SET_D2SH_DIS,
    POWER_SET_FAST_CHARGE_SW,
    POWER_GET_FAST_CHARGE_STA,
};




/********************************************************************************/
/*
 *      bluetooth power off recover link
 */
void bt_poweroff_recover(void);
/********************************************************************************/
/*
 *      bluetooth link request power manager on
 */
void bt_power_on(void *priv);

/********************************************************************************/
/*
 *      bluetooth link request power manager off
 */
void bt_power_off(void *priv);

/********************************************************************************/
/*
 *      bluetooth lock power manager
 */
void bt_power_off_lock();

/********************************************************************************/
/*
 *      bluetooth unlock power manager
 */
void bt_power_off_unlock();

/********************************************************************************/
/*
 *      bluetooth link get power manager unit
 */
void *bt_power_get(void *priv, const struct bt_power_operation *ops);

/********************************************************************************/
/*
 *      bluetooth link delete power manager unit
 */
void bt_power_put(void *priv);


void bt_power_init(const struct bt_low_power_param *param);

u8 bt_power_is_poweroff_probe();

u8 bt_power_is_poweroff_post();

void bt_power_lwr_deal_register_handle(void (*handle)(u8 mode, u32 timer_ms));

void test_power_init(void);

void fast_charge_sw(u8 sw);

u32 get_fast_charge_sta(void);

void set_pwrmd(u8 sm);

#endif

